﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalP3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //10. Create 5 Item objects
            
            Item item1 = new Item("Xavi", 00005, 57.99, "Adidas", "Person", true);
            Item item2 = new Item("Ola", 00004, 7.99, "Nike", "Person", false);
            Item item3 = new Item("Dog", 00002, 67.99, "Woof", "Animal", true);
            Item item4 = new Item("Leaf", 00003, 997.99, "Bob Marley", "Plant", true);
            Item item5 = new Item("Fred", 00015, 17.99, "Underarmour", "Person", false);




            //11. Create an array for the Item options

            Item[] items = new Item[] { item1, item2, item3, item4, item5 };


            //14. Display the item objects using the method created in step 12.
            DisplayBoat(items);

            /*15. Create the following modifications to the item objects:
             * Object 1 - change the name
             * Object 2 - change the price
             * object 3 - change the manufacturer
             * object 4 - change the stocked value to false
             * object 5 - change the type
             */
            item1.ItemName = "Mason";
            item2.ItemPrice = 100.00;
            item3.ItemManufacturer = "Underarmour";
            item4.isNotInStock();
            item5.ItemType = "Alien";




            //16. Display the changes
            DisplayBoat(items);
        }


        //12. Complete the method to display each item object from the array. Be sure to use the correct loop type and parameters for both the method and loop.
        static void DisplayBoat(Item[] items)
        {
            foreach (Item item in items)
            {
                Console.WriteLine(item);
                Console.WriteLine();
            }
        }
    }
    
}
