﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalP3
{
    internal class Item
    {
        //1. Declare the variables needed as stated in the directions. Make sure to give them the proper access level and data types. You will need to use these in step(s) 3-5.
        private string _itemName;
        private int _itemID;
        private double _itemPrice;
        private string _itemManufacturer;
        private string _itemType;
        private bool _inStock;

        //2. Complete the constructor. Be sure to add the correct parameters and logic.
        public Item(string itemName, int itemID, double itemPrice, string itemManufacturer, string itemType, bool inStock)
        {
            _itemName = itemName;
            _itemID = itemID;
            _itemPrice = itemPrice;
            _itemManufacturer = itemManufacturer;
            _itemType = itemType;
            _inStock = inStock; 
        }

        //3 - 5. Complete the properties for ItemName, ItemId, ItemPrice, ItemManufacturer, ItemType
        public string ItemName
        {
            get { return _itemName; }   
            set { _itemName = value; }

        }
        public int ItemId//make sure that you validate as stated in the directions
        {
            get { return _itemID; }
            set
            {
                if (value >= 1 && value <= 99999)
                    _itemID = value;
                else
                    _itemID = 00000;
            }

            
        }
        public double ItemPrice//make sure that you validate as stated in the directions
        {
            get { return _itemPrice; }  
            set
            {
                if (value > 0)
                    _itemPrice = value;
                else
                    _itemPrice = 0.00;
            }

        }
        public string ItemManufacturer
        {
            get { return _itemManufacturer; }
            set { _itemManufacturer = value; }

        }
        public string ItemType
        {
            get { return _itemType; }
            set { _itemType = value; }  

        }

        //6 - 8. Complete the three methods to determine if the item is in stock.

        public bool IsInStock()
        {
            return _inStock;
        }

        public void isNotInStock()
        {
            _inStock = false;
        }

        public void Stock()
        {
            _inStock = true;
        }

        //9. Complete the overrride ToString Method to display your properties. Make sure the output looks similar to the example provided in the directions.
        public override string ToString()
        {
            return $"Item Name: {ItemName}\nID: {ItemId}\nManufacturer: {ItemManufacturer}\nType: {ItemType}\nPrice: ${ItemPrice.ToString("0.00")}\nIn stock?: {_inStock}"; 
        }
    }
}
